from edbz.core import EssaimDeBord

essaim = EssaimDeBord()
print(essaim.add_agent("drone1"))
print(essaim.coordinate())
print(essaim.secure_communication("Test message"))

class EssaimDeBord:
    def __init__(self):
        self.agents = []

    def add_agent(self, agent_name):
        self.agents.append(agent_name)
        return f"Agent ajouté : {agent_name}"

    def coordinate(self):
        return f"Coordination de {len(self.agents)} agents en cours"

    def secure_communication(self, message):
        return f"Message sécurisé envoyé : {message}"

from edbz.core import EssaimDeBord

def test_add_agent():
    essaim = EssaimDeBord()
    assert "Agent ajouté" in essaim.add_agent("drone1")
